#!usr/bin/env python3
import json


def json_formatter(data):
    return json.dumps(data)
