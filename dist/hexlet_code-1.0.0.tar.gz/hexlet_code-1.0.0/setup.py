# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.formatters', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['env>=0.1.0,<0.2.0', 'hexlet-immutable-fs-trees>=0.1.8,<0.2.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '1.0.0',
    'description': '',
    'long_description': "### Hexlet tests and linter status:\n[![Actions Status](https://github.com/KonstantinShevlyakov/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/KonstantinShevlyakov/python-project-50/actions)\n\n### Maintainability\n[![Maintainability](https://api.codeclimate.com/v1/badges/ff8dcaf914c52641b434/maintainability)](https://codeclimate.com/github/KonstantinShevlyakov/python-project-50/maintainability)\n\n### Test Coverage\n[![Test Coverage](https://api.codeclimate.com/v1/badges/ff8dcaf914c52641b434/test_coverage)](https://codeclimate.com/github/KonstantinShevlyakov/python-project-50/test_coverage)\n\n### Github Actions\n[![Github Actions Status](https://github.com/KonstantinShevlyakov/python-project-50/workflows/Python%20CI/badge.svg)](https://github.com/KonstantinShevlyakov/python-project-50/actions)\n\n### Diff between JSON's  demo\n[![asciicast](https://asciinema.org/a/Er0TOQcqVQXNMNr1fVHjfSKfn.svg)](https://asciinema.org/a/Er0TOQcqVQXNMNr1fVHjfSKfn)\n",
    'author': 'Konstantin Shevlyakov',
    'author_email': 'shevlyakov.ka@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
