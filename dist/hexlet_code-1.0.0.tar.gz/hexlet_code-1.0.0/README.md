### Hexlet tests and linter status:
[![Actions Status](https://github.com/KonstantinShevlyakov/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/KonstantinShevlyakov/python-project-50/actions)

### Maintainability
[![Maintainability](https://api.codeclimate.com/v1/badges/ff8dcaf914c52641b434/maintainability)](https://codeclimate.com/github/KonstantinShevlyakov/python-project-50/maintainability)

### Test Coverage
[![Test Coverage](https://api.codeclimate.com/v1/badges/ff8dcaf914c52641b434/test_coverage)](https://codeclimate.com/github/KonstantinShevlyakov/python-project-50/test_coverage)

### Github Actions
[![Github Actions Status](https://github.com/KonstantinShevlyakov/python-project-50/workflows/Python%20CI/badge.svg)](https://github.com/KonstantinShevlyakov/python-project-50/actions)

### Diff between JSON's  demo
[![asciicast](https://asciinema.org/a/Er0TOQcqVQXNMNr1fVHjfSKfn.svg)](https://asciinema.org/a/Er0TOQcqVQXNMNr1fVHjfSKfn)
